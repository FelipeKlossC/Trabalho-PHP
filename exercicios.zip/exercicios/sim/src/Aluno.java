public class Aluno {
    public String matricula 
}
